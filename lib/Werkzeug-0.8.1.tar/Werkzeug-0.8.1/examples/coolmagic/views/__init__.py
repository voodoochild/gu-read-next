# -*- coding: utf-8 -*-
"""
    coolmagic.views
    ~~~~~~~~~~~~~~~

    This module collects and assambles the urls.

    :copyright: (c) 2009 by the Werkzeug Team, see AUTHORS for more details.
    :license: BSD, see LICENSE for more details.
"""
